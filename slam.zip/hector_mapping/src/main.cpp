//=================================================================================================
// Copyright (c) 2011, Stefan Kohlbrecher, TU Darmstadt
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Simulation, Systems Optimization and Robotics
//       group, TU Darmstadt nor the names of its contributors may be used to
//       endorse or promote products derived from this software without
//       specific prior written permission.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//=================================================================================================

#include <ros/ros.h>

#include "HectorMappingRos.h"
#include <nav_msgs/Odometry.h>
void setScanData(sensor_msgs::LaserScan *scan, char *readBuf, long long int *stamp, long int addTime)
{
  char *tmpptr;
  long int a;
  long int b;
  long long int wk;
  float aaa;

  tmpptr = strtok(readBuf, ",\n");
  scan->ranges.erase(scan->ranges.begin(), scan->ranges.end());
  scan->intensities.erase(scan->intensities.begin(), scan->intensities.end());

  for (int i = 1; i < 730; i++)
  {
    tmpptr = strtok(NULL, ",\n");
    switch (i)
    {
    case 1:
      scan->header.seq = atoi(tmpptr);
      break;
    case 2:
      wk = (long long int)atoll(tmpptr);
      *stamp = wk;
      a = wk / 1000000000;
      b = wk - a * 1000000000;
      a += addTime;

      scan->header.stamp = ros::Time(a, b);
      break;
    case 3:
      scan->header.frame_id = tmpptr;
      break;
    case 4:
      scan->angle_min = atof(tmpptr);
      break;
    case 5:
      scan->angle_max = atof(tmpptr);
      break;
    case 6:
      scan->angle_increment = atof(tmpptr);
      break;
    case 7:
      scan->time_increment = atof(tmpptr);
      break;
    case 8:
      scan->scan_time = atof(tmpptr);
      break;
    case 9:
      scan->range_min = atof(tmpptr);
      break;
    case 10:
      scan->range_max = atof(tmpptr);
      break;
    default:
      if (i >= 11 && i <= 370)
      {
        if (strcmp(tmpptr, "inf") != 0)
        {
          scan->ranges.push_back(atof(tmpptr));
        }
        else
        {
          scan->ranges.push_back(0);
        }
      }
      else
      {
        //aaa = atof(tmpptr);
        //std::cout << "<< " << i << " " << aaa << "\n";
        scan->intensities.push_back(0);
      }
      break;
    }
  }
}

void setOdomData(nav_msgs::Odometry *odom, char *readBuf, long long int *stamp, long int addTime)
{
  char *tmpptr;
  long int a;
  long int b;
  long long int wk;

  tmpptr = strtok(readBuf, ",\n");

  for (int i = 1; i < 89; i++)
  {
    tmpptr = strtok(NULL, ",\n");
    switch (i)
    {
    case 1:
      odom->header.seq = atoi(tmpptr);
      break;
    case 2:
      wk = (long long int)atoll(tmpptr);
      *stamp = wk;
      a = wk / 1000000000;
      b = wk - a * 1000000000;
      a += addTime;

      odom->header.stamp = ros::Time(a, b); //(ros::Time)atoll(tmpptr);
      break;
    case 3:
      odom->header.frame_id = tmpptr;
      break;
    case 4:
      odom->child_frame_id = tmpptr;
      break;
    case 5:
      odom->pose.pose.position.x = atof(tmpptr);
      break;
    case 6:
      odom->pose.pose.position.y = atof(tmpptr);
      break;
    case 7:
      odom->pose.pose.position.z = atof(tmpptr);
      break;
    case 8:
      odom->pose.pose.orientation.x = atof(tmpptr);
      break;
    case 9:
      odom->pose.pose.orientation.y = atof(tmpptr);
      break;
    case 10:
      odom->pose.pose.orientation.z = atof(tmpptr);
      break;
    case 11:
      odom->pose.pose.orientation.w = atof(tmpptr);
      break;
    case 48:
      odom->twist.twist.linear.x = atof(tmpptr);
      break;
    case 49:
      odom->twist.twist.linear.y = atof(tmpptr);
      break;
    case 50:
      odom->twist.twist.linear.z = atof(tmpptr);
      break;
    case 51:
      odom->twist.twist.angular.x = atof(tmpptr);
      break;
    case 52:
      odom->twist.twist.angular.y = atof(tmpptr);
      break;
    case 53:
      odom->twist.twist.angular.z = atof(tmpptr);
      break;
    default:
      if (i >= 12 && i <= 47)
      {
        odom->pose.covariance[i - 12] = atof(tmpptr);
      }
      else
      {
        odom->twist.covariance[i - 54] = atof(tmpptr);
      }
      break;
    }
  }
}

bool findOdomData(FILE **fp, nav_msgs::Odometry &odomData, long long int stamp, long int addTime)
{
  nav_msgs::Odometry wkCurOdom;
  nav_msgs::Odometry wkOldOdom;
  char tmp[50000];
  long long int wkstamp;

  if (*fp == NULL)
  {
    *fp = std::fopen("/home/ubuntu/catkin_ws_ahector/src/hector_slam/hector_mapping/csv/hmodel_pat1_1_odom.csv", "r");
    if (*fp == NULL)
    {
      return (false);
    }
  }

  fgets(tmp, sizeof(tmp), *fp);
  while (fgets(tmp, sizeof(tmp), *fp) != NULL)
  {
    setOdomData(&wkCurOdom, tmp, &wkstamp, addTime);
    if (wkstamp <= stamp)
    {
      wkOldOdom = wkCurOdom;
    }
    else
    {
      odomData = wkOldOdom;
      break;
    }
  }
  return (true);
}

int main(int argc, char **argv)
{
  
  ros::init(argc, argv, "hector_slam");

  HectorMappingRos sm;
  long long int startTime = 0 * (long long int)1000000000;
  long long int playTime = 10000 * (long long int)1000000000;
  long long int startTimeR;
  long long int endTimeR;
  HectorInit *hi = sm.getHectorInitObject();
  sensor_msgs::LaserScan tmpScan;
  long long int stamp;
  nav_msgs::Odometry wkOdom;
  FILE *fp = NULL;
  char tmp[50000];
  char tmp2[50000];
  time_t t = time(NULL);
  long long int addTime;
  FILE *odom_fp = NULL;

  fp = std::fopen("/home/liu/catkin_ws_ahector/src/hector_slam/hector_mapping/csv/hmodel_pat1_1_laser.csv", "r");
  if (fp == NULL)
  {
    return (1);
  }

  bool initFlg = true;
  fgets(tmp, sizeof(tmp), fp);
  while (fgets(tmp, sizeof(tmp), fp) != NULL)
  {
    if (initFlg == true)
    {
      memcpy(tmp2, tmp, sizeof(tmp));
      setScanData(&tmpScan, tmp2, &stamp, 0);
      addTime = t - (stamp / 1000000000) + 1000;
      setScanData(&tmpScan, tmp, &stamp, addTime);
      startTimeR = stamp + startTime;
      endTimeR = startTimeR + playTime;
      initFlg = false;
    }
    else
    {
      setScanData(&tmpScan, tmp, &stamp, addTime);
      if (stamp >= startTimeR && stamp <= endTimeR)
      {
        //std::cout << "time:" << (stamp - startTimeR)/1000000000.0f << "\n";
        findOdomData(&odom_fp, wkOdom, stamp, addTime);

        ros::Time().setNow(wkOdom.header.stamp);
        hi->odometryCallback(wkOdom);

        ros::Time().setNow(tmpScan.header.stamp);
        sm.GimmicScanCallback(tmpScan, wkOdom);
        //sm.scanCallback(tmpScan);
      }
      if (stamp > endTimeR)
      {
        break;
      }
    }
  }
  std::fclose(fp);
  std::fclose(odom_fp);

  return (0);
}
