#ifndef _HECTORINIT_H_
#define _HECTORINIT_H_

#include <iostream>
#include <nav_msgs/Odometry.h>



class HectorInit{
public:
  HectorInit();
  void setLidarReference(const tf::Transform& t);
  void setOdometryReference();
  void getCurrentTransform(tf::Transform& t);
  void odometryCallback(const nav_msgs::Odometry& odom);
private:
  std::string odomTopic;
  tf::Transform lidarTransform;
  tf::Transform odometryTransform;
  nav_msgs::Odometry lastOdom;
  ros::Subscriber odomSub;
};



inline void setIdentity(nav_msgs::Odometry& o){
  o.pose.pose.position.x=o.pose.pose.position.y=o.pose.pose.position.z=0;
  o.pose.pose.orientation.x=o.pose.pose.orientation.y=o.pose.pose.orientation.z=0;
  o.pose.pose.orientation.w=1;
}


inline HectorInit::HectorInit():
  odomTopic("/Rulo/odom")
{
  ros::NodeHandle node;
  odomSub = node.subscribe(odomTopic, 1, &HectorInit::odometryCallback,this);
  lidarTransform.setIdentity();
  odometryTransform.setIdentity();
  setIdentity(lastOdom);
  //std::cout<<"constructed"<<std::endl;
}

inline tf::Transform odomToTransform(const nav_msgs::Odometry& odom){
  tf::Transform t;
  t.setOrigin(tf::Vector3(odom.pose.pose.position.x,
                          odom.pose.pose.position.y,
                          odom.pose.pose.position.z
                          )
              );
  t.setRotation(tf::Quaternion(odom.pose.pose.orientation.x,
                               odom.pose.pose.orientation.y,
                               odom.pose.pose.orientation.z,
                               odom.pose.pose.orientation.w                               
                               )
                );
  return t;
}



inline void HectorInit::setOdometryReference(){
  //std::cout<<"set odom ref"<<std::endl;
  odometryTransform=odomToTransform(lastOdom);
}

inline void HectorInit::setLidarReference(const tf::Transform& t){
  //std::cout<<"set lidar ref"<<std::endl;
  lidarTransform=t;
}
  

inline void HectorInit::odometryCallback(const nav_msgs::Odometry& odom){
  //std::cout<<"odom callback"<<std::endl;
  lastOdom=odom;   
}


inline void HectorInit::getCurrentTransform(tf::Transform& t){
  //std::cout<<"getcurrent{"<<std::endl;
  t=lidarTransform*odometryTransform.inverseTimes(odomToTransform(lastOdom));
  //std::cout<<"}getcurrent"<<std::endl;
}


#endif

