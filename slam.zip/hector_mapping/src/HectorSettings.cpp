#include <math.h>
#include <slam_main/HectorSettings.h>

const double HectorSettings::SCAN_HALFRANGE=M_PI/180*270/2;
const double HectorSettings:: TAU5=M_PI/3;
const std::string HectorSettings::ODOMETRY_ROS_TOPIC="/Rulo/odom";


