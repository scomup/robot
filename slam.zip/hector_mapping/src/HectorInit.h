#ifndef _HECTORINIT_H_
#define _HECTORINIT_H_

#include <iostream>
#include <nav_msgs/Odometry.h>
#include "tf/tf.h"

/*
  This class provides the initial estimate used to initialize  Hector's optimization. 
  This initial estimate is computed as Hector's previous output+ (current odometry - odometry at the time of Hector's previous output)
 */


class HectorInit{
public:
  HectorInit(const std::string& odomTopic);
  void setLidarReference(const tf::Transform& t); //notify a new Hector's output 
  void storeOdometryReference();//save the current odometry for later use
  void setOdometryReference(); //set the odometry saved by storeOdometryReference as the odometry correponding to the Hector's output set by setLidarReference
  void getCurrentTransform(tf::Transform& t);//get Hector's previous output+ (current odometry - odometry at the time of Hector's previous output)
  bool isOdometryArrived(); //tells if a new odometry update is arrived after last notification of an Hector's output
#if 1 //Shimasaki
  void odometryCallback(const nav_msgs::Odometry& odom); //called by the ROS subscriber
#endif
private:
#if 0 //Shimasaki
  void odometryCallback(const nav_msgs::Odometry& odom); //called by the ROS subscriber
#endif
  std::string odomTopic;
  tf::Transform lidarTransform;
  tf::Transform odometryTransform,nextOdometryTransform;
  nav_msgs::Odometry lastOdom;
  ros::Subscriber odomSub;
  bool newOdom;
};



#endif

