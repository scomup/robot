#include "HectorInit.h"

 void setIdentity(nav_msgs::Odometry& o){
  o.pose.pose.position.x=o.pose.pose.position.y=o.pose.pose.position.z=0;
  o.pose.pose.orientation.x=o.pose.pose.orientation.y=o.pose.pose.orientation.z=0;
  o.pose.pose.orientation.w=1;
}


 HectorInit::HectorInit(const std::string& _odomTopic):
   odomTopic(_odomTopic),
   newOdom(false)
{
  ros::NodeHandle node;
  odomSub = node.subscribe(odomTopic, 1, &HectorInit::odometryCallback,this);
  lidarTransform.setIdentity();
  odometryTransform.setIdentity();
  setIdentity(lastOdom);
}

tf::Transform HectorInit::odomToTransform(const nav_msgs::Odometry& odom){
  tf::Transform t;
  t.setOrigin(tf::Vector3(odom.pose.pose.position.x,
                          odom.pose.pose.position.y,
                          odom.pose.pose.position.z
                          )
              );
  t.setRotation(tf::Quaternion(odom.pose.pose.orientation.x,
                               odom.pose.pose.orientation.y,
                               odom.pose.pose.orientation.z,
                               odom.pose.pose.orientation.w                               
                               )
                );
  return t;
}



std::string format(const tf::Transform& t){
  tfScalar yaw, pitch, roll;
  t.getBasis().getEulerYPR(yaw, pitch, roll);
  char buffer[256];
  sprintf(buffer,"%.2f,%.2f@%.2f\n",t.getOrigin().getX(),t.getOrigin().getY(),yaw);
  return buffer;
}


void HectorInit::storeOdometryReference(){
  //std::cout<<"set odom ref"<<std::endl;
  nextOdometryTransform=odomToTransform(lastOdom);
}



void HectorInit::setOdometryReference(){
  //std::cout<<"set odom ref"<<format(nextOdometryTransform)<<std::endl;
  odometryTransform=nextOdometryTransform;
}

void HectorInit::setLidarReference(const tf::Transform& t){
  //std::cout<<"set lidar ref "<<format(t)<<std::endl;
  lidarTransform=t;
  newOdom=false;
}
  

void HectorInit::odometryCallback(const nav_msgs::Odometry& odom){  
  lastOdom=odom;   
  newOdom=true;

// Shimasaki
  tf::Transform wk = odomToTransform(odom);

  tfScalar yaw, pitch, roll;
  wk.getBasis().getEulerYPR(yaw, pitch, roll);
  char buffer[256];
  sprintf(buffer,"odo,%.2f,%.2f,%.2f",wk.getOrigin().getX(),wk.getOrigin().getY(),yaw*180/M_PI);
  //std::cout << "" << buffer << "\n";

  //  std::cout<<180/M_PI*atan2(odom.pose.pose.orientation.z, odom.pose.pose.orientation.w) * 2<<std::endl;
}


void HectorInit::getCurrentTransform(tf::Transform& t){
  t=lidarTransform*odometryTransform.inverseTimes(odomToTransform(lastOdom));
  //std::cout<<"current transform "<<format(t)<<std::endl;
}

bool HectorInit::isOdometryArrived(){
  return newOdom;
}
