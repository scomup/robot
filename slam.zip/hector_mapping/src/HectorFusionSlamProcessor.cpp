#include <iostream>
#include "HectorFusionSlamProcessor.h"
#include <hector_slam_lib/map/GridMap.h>

 

hectorslam::HectorFusionSlamProcessor::HectorFusionSlamProcessor(float mapResolution, int mapSizeX, int mapSizeY , const Eigen::Vector2f& startCoords, int multi_res_size, DrawInterface* drawInterfaceIn, HectorDebugInfoInterface* debugInterfaceIn):
  HectorSlamProcessor(mapResolution,mapSizeX, mapSizeY , startCoords, multi_res_size, drawInterfaceIn , debugInterfaceIn),
  hectorInit(HectorSettings::ODOMETRY_ROS_TOPIC)
{
}



Eigen::Vector3f hectorslam::rosTransformToHectorPose(const tf::Transform& t){
  tfScalar yaw, pitch, roll;
  t.getBasis().getEulerYPR(yaw, pitch, roll);
  return Eigen::Vector3f(t.getOrigin().getX(),t.getOrigin().getY(), yaw);
}

tf::Transform  hectorslam::hectorPoseToRosTransform(const Eigen::Vector3f& p){  
  tf::Transform t;
  geometry_msgs::Pose pose;
  pose.position.x = p.x();
  pose.position.y = p.y();
  pose.position.z=0;  
  pose.orientation.x=0;
  pose.orientation.y=0;    
  pose.orientation.w = cos(p.z()*0.5f);
  pose.orientation.z = sin(p.z()*0.5f);
  tf::poseMsgToTF(pose, t);
  return t;
}


void hectorslam::HectorFusionSlamProcessor::update(const DataContainer& dataContainer, const Eigen::Vector3f& poseHintWorld, bool map_without_matching )
{
  if (!hectorInit.isOdometryArrived()){
    //std::cout<<"no odom"<<std::endl;
    return;
  }
  //std::cout<<"update"<<std::endl;
  tf::Transform currTransform;              
  hectorInit.storeOdometryReference();
  hectorInit.getCurrentTransform(currTransform);

  HectorSlamProcessor::update(dataContainer,hectorslam::rosTransformToHectorPose(currTransform),map_without_matching);

 
  
  hectorInit.setLidarReference(hectorslam::hectorPoseToRosTransform(getLastScanMatchPose()) );

  hectorInit.setOdometryReference();  
}
