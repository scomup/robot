#ifndef _HECTORFUSIONSLAMPROCESSOR_H_
#define _HECTORFUSIONSLAMPROCESSOR_H_

#include "slam_main/HectorSlamProcessor.h"
#include "HectorInit.h"

namespace hectorslam{


  /*
    Fuses the odometry information with lidar information. Most of the computation is done by HectorInit. 
    This class deals mainly with data format conversions
   */
  
  class HectorFusionSlamProcessor:public HectorSlamProcessor{
  public:
    HectorFusionSlamProcessor(float mapResolution, int mapSizeX, int mapSizeY , const Eigen::Vector2f& startCoords, int multi_res_size, DrawInterface* drawInterfaceIn = 0, HectorDebugInfoInterface* debugInterfaceIn = 0);

    void update(const DataContainer& dataContainer, const Eigen::Vector3f& poseHintWorld, bool map_without_matching = false);
#if 0
  private:
#else
  public:
#endif
    HectorInit hectorInit;

  };

  Eigen::Vector3f rosTransformToHectorPose(const tf::Transform& t);
  tf::Transform  hectorPoseToRosTransform(const Eigen::Vector3f& t);
  

}//ns hectorslam






#endif
