#ifndef _HECTORFILTER_H_
#define _HECTORFILTER_H_

namespace hectorslam{

  static const float WALL_RESOLUTION=0.30; //in meters
  static const int MIN_ROBUSTNESS=10;  //minimum number of points for a wall

  /*The filter's * operator computes (in an optimized way) 
       R^-1*W*R*lidarEstimate +R^-1*(1-W)*R*initEstimate
       where
       R is a rotation matrix computed such that the lidar estimation is the highest along the x axis
       W is a diagonal weigh matrix, where each element is binary, and equal to 1 if the robustness 
          (see getRobustPhi) along that axis (respectively x and y) is greater than the constant MIN_ROBUSTNESS
   */
  

  class HectorFilter{
    
  public:
    HectorFilter(const hectorslam::DataContainer& dataContainer,const Eigen::Vector3f& initEstimate,int* r){
      Eigen::Vector2i  robustness;
      float bestPhi;
      getRobustPhi(robustness,bestPhi ,dataContainer);
      //std::cout<<"phi="<<(bestPhi*180/M_PI)<<"r[0]"<<robustness[0]<<" r[1]"<<robustness[1]<<std::endl;
      
      int r0=robustness[0]>MIN_ROBUSTNESS?1:0;
      int r1=robustness[1]>MIN_ROBUSTNESS?1:0;
      r[0] = r0;
      r[1] = r1;

      float c=cos(bestPhi),s=sin(bestPhi);
// Shimasaki
//      std::cout<< "r0: " << r0 << ",r1: " << r1 << "\n";
//      std::cout<< r0 << "," << r1 << "\n";

      Eigen::Matrix3f initMultiplier;
      
      lidarMultiplier<< 
      c*c*r0+s*s*r1,c*s*(r0-r1)  ,0,
        c*s*(r0-r1)  ,c*c*r1+s*s*r0,0,
        0            ,0            ,1;
      
      
      initMultiplier<< 
        c*c*(1-r0)+s*s*(1-r1),c*s*(-r0+r1)  ,0,
        c*s*(-r0+r1)  ,c*c*(1-r1)+s*s*(1-r0),0,
        0            ,0            ,0;

      lidarOffset=initMultiplier*initEstimate;
    }

    Eigen::Vector3f operator*(const Eigen::Vector3f& lidarEstimate){
      return lidarOffset+lidarMultiplier*lidarEstimate;
    }


  private:
    /* countHeighest computes an histogram of the projection of the points p along the direction
       (cos(phi),sin(phi)). Each bin has unit size. The first bin corresponds to a value of the 
       (rounded) projection equal to -maxr.
       The histogram is returned in count. The function returns the sum of the two highest values
       in the histogram (which usually correspond to sidewalls).
     */

    static int countHighest(Eigen::VectorXi& count,int maxr,const Eigen::MatrixXf&p, double phi){
        Eigen::RowVector2f dirv(cos(phi),sin(phi));
        
        Eigen::VectorXf proj=dirv*p;
        count.setZero();
        for (size_t i=0;i<p.cols();i++){
          count[maxr+round(proj(i))]++;
        }
        int hc1=0,hc2=0;
        
        for (size_t i=0;i<count.size();i++){
          int c=count[i];
          if (c>hc1){
            hc2=hc1;
            hc1=c;
          }else if (c>hc2){
            hc2=c;
          }
        }
        return hc1+hc2; 
      }

    /*
      Given the dataPoints, the function computes the rotation bestPhi that assures the best robustness for the x axis.
      The function also returns the robustness along the two axis (x and y)
      Robustness is here defined as the value returned by countHeighest
     */
    
      static void getRobustPhi(Eigen::Vector2i&  robustness,float& bestPhi ,const hectorslam::DataContainer& dataPoints){
        int npts=dataPoints.getSize();
        
        Eigen::MatrixXf p(2,npts);
        for (size_t i=0;i<npts;++i){
          p.col(i)=dataPoints.getVecEntry(i)/WALL_RESOLUTION;
        }
        int maxr=1+ceil(sqrt(p.array().square().colwise().sum().maxCoeff()));
        Eigen::VectorXi  count(maxr*2+1);           
        int bestCount=0;
        bestPhi=0;
        for (float phi=0;phi<M_PI;phi+=M_PI/180){
          int hc=countHighest(count,maxr,p,phi);
          if (hc>bestCount){
            bestCount=hc;
            bestPhi=phi;
          }
        }
        
        robustness[0]=bestCount;
        robustness[1]=countHighest(count,maxr,p,bestPhi+M_PI/2);       
      }//getRobustPhi
      
      
      Eigen::Matrix3f lidarMultiplier;
      Eigen::Vector3f lidarOffset;

  };//class HectorFilter
  


}//ns hectorslam



#endif
