#ifndef _HECTOR_SETITINGS_H_
#define _HECTOR_SETITINGS_H_

#include <stdbool.h>
#include <string>

class HectorSettings{
public:
  
  static const bool STABLE_INVERSION=true;
  static const bool FUSE_INITIAL_ESTIMATION=true;
  static const bool OPTIMIZE_ONLY_TRANSLATION=false;
  static const bool MULTIPLE_INITIAL_HYPHOTHESIS=false;


  static const double SCAN_HALFRANGE;
  static const double TAU5;
  static const std::string ODOMETRY_ROS_TOPIC;

};
  
#endif
